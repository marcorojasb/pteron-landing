/**
 * Lenguaje visual de pteron 1.0.0 (2026-10-12): los valores de kit/tokens.json para TypeScript.
 * Generado por scripts/kit.mjs; no se edita a mano.
 */
export const COLOR = {
  /** Texto. El de las hojas de pteron (classroom.ink). */
  "tinta": "#1F2A3D",
  /** Títulos, enlaces, la marca y la acción dominante en la app (classroom.navy). */
  "azul": "#1E3F94",
  /** El azul al presionar, y el texto sobre el lápiz (7,4 : 1). */
  "azul-hondo": "#162F70",
  /** El destacador. En la web, además, la acción principal de una vista; nunca en cápsulas ni de fondo. En la app reemplaza al dorado sólo como destacador: nunca en un estado interactivo. */
  "lapiz": "#F0C060",
  /** El borde y el estado presionado del lápiz. */
  "lapiz-hondo": "#E2AC3A",
  /** El fondo: el lienzo de Write, detrás de cada hoja. */
  "mesa": "#E9EDF1",
  /** La mesa bajo el cursor o en una franja. */
  "mesa-honda": "#DEE3EA",
  /** Lo que es papel: hojas, tarjetas, el reverso de una lámina. */
  "hoja": "#FFFFFF",
  /** Texto secundario (classroom.muted): 4,6 : 1 sobre la mesa y 5,4 : 1 sobre la hoja. */
  "grafito": "#5B6B82",
  /** El texto de ejemplo de un campo, sólo sobre la hoja (4,6 : 1); sobre la mesa queda en 3,9 : 1. */
  "suave": "#68778C",
  /** Las reglas entre filas y secciones. */
  "regla": "#DCE3EE",
  /** Bordes de controles y cuadros. */
  "linea": "#C9D3E1",
  /** Texto secundario sobre el azul (6,4 : 1). */
  "sobre-azul": "#C9D3EA",
  /** Enlaces sobre el azul (7,4 : 1). */
  "sobre-azul-claro": "#DCE3F2",
  /** Las sombras son de tinta, nunca negras ni de color. */
  "sombra": "#1F2A3D",
  /** Éxito: texto. */
  "estado-ok": "#1D5C3C",
  /** Éxito: fondo. */
  "estado-ok-papel": "#EAF5EF",
  /** Éxito: borde. */
  "estado-ok-borde": "#CBE5D6",
  /** Error: texto. */
  "estado-error": "#9A2F23",
  /** Error: fondo. */
  "estado-error-papel": "#FBEDEB",
  /** Error: borde. */
  "estado-error-borde": "#F0C9C4",
  /** Nota: fondo. */
  "estado-nota-papel": "#F2F6FC",
  /** Nota: borde. */
  "estado-nota-borde": "#D6E0EF",
  /** Aviso: fondo. */
  "estado-aviso-papel": "#FDF5E2",
  /** Aviso: borde. */
  "estado-aviso-borde": "#EDD49B",
} as const;

export const COLOR_OSCURO = {
  /** Texto. */
  "tinta": "#E6EBF3",
  /** Títulos, enlaces, selección, foco y la acción dominante sobre fondo oscuro, con texto #0E1A33 encima (8,6 : 1 sobre la mesa). */
  "azul": "#8FB0F4",
  /** El azul al presionar: en lo oscuro, más claro. */
  "azul-hondo": "#B3C4F4",
  /** El destacador, igual que en lo claro. */
  "lapiz": "#F0C060",
  /** Borde y estado presionado del lápiz. */
  "lapiz-hondo": "#E2AC3A",
  /** El fondo. */
  "mesa": "#0E131B",
  /** La mesa en una franja o bajo el cursor: en lo oscuro, más clara. */
  "mesa-honda": "#1C2430",
  /** Superficies: paneles, tarjetas. */
  "hoja": "#151B25",
  /** Texto secundario (8,5 : 1 sobre la mesa). */
  "grafito": "#A3B0C2",
  /** El tercer nivel de texto (5 : 1 sobre la hoja). */
  "suave": "#7D8BA0",
  /** Reglas entre filas. */
  "regla": "#232C3A",
  /** Bordes de controles. */
  "linea": "#2C3646",
} as const;

/** Lo que sólo usa la app. */
export const COLOR_APP = {
  /** El texto secundario de la app sobre la mesa: el rótulo de campo de las hojas (6 : 1 sobre la mesa). El grafito queda como tercer nivel. En oscuro, grafito y suave. */
  "rotulo": "#4A5A72",
  /** Paneles y fondos entre la mesa y la hoja: el lavado de pteron-design. */
  "lavado": "#F3F6FB",
  /** El lavado en el tema oscuro. */
  "lavado-oscuro": "#12171F",
} as const;

export const MARCA = {
  viewBox: "-1436 -684 2872 886",
  /** El espacio libre por lado, en unidades del contorno: el alto de la «o». */
  aire: 504,
  minimoPantallaPx: 30,
  minimoPapelMm: 8,
} as const;

export const ICONO = {
  lienzo: 1024,
  radio: 229,
  radioFavicon: 200,
} as const;

export type ColorPteron = keyof typeof COLOR;
