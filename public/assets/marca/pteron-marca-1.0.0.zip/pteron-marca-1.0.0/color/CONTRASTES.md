# Contrastes del lenguaje 1.0.0

Medidos con la fórmula de WCAG 2.2. Texto normal: 4,5 : 1 como mínimo. Generado por scripts/kit.mjs.

## Claro

| Par | Colores | Contraste | |
| --- | --- | --- | --- |
| tinta sobre mesa | #1F2A3D / #E9EDF1 | 12,25 : 1 | cumple |
| tinta sobre hoja | #1F2A3D / #FFFFFF | 14,41 : 1 | cumple |
| azul sobre mesa | #1E3F94 / #E9EDF1 | 8,14 : 1 | cumple |
| azul sobre hoja | #1E3F94 / #FFFFFF | 9,57 : 1 | cumple |
| grafito sobre mesa | #5B6B82 / #E9EDF1 | 4,61 : 1 | cumple |
| grafito sobre hoja | #5B6B82 / #FFFFFF | 5,43 : 1 | cumple |
| suave sobre hoja | #68778C / #FFFFFF | 4,56 : 1 | cumple |
| hoja sobre azul | #FFFFFF / #1E3F94 | 9,57 : 1 | cumple |
| azul-hondo sobre lapiz | #162F70 / #F0C060 | 7,41 : 1 | cumple |
| tinta sobre lapiz | #1F2A3D / #F0C060 | 8,52 : 1 | cumple |
| sobre-azul sobre azul | #C9D3EA / #1E3F94 | 6,38 : 1 | cumple |
| sobre-azul-claro sobre azul | #DCE3F2 / #1E3F94 | 7,44 : 1 | cumple |
| estado-ok sobre estado-ok-papel | #1D5C3C / #EAF5EF | 7,10 : 1 | cumple |
| estado-error sobre estado-error-papel | #9A2F23 / #FBEDEB | 6,57 : 1 | cumple |
| linea sobre hoja | #C9D3E1 / #FFFFFF | 1,51 : 1 | borde, no texto |

## Oscuro (la app)

| Par | Colores | Contraste | |
| --- | --- | --- | --- |
| tinta sobre mesa | #E6EBF3 / #0E131B | 15,56 : 1 | cumple |
| tinta sobre hoja | #E6EBF3 / #151B25 | 14,43 : 1 | cumple |
| azul sobre mesa | #8FB0F4 / #0E131B | 8,59 : 1 | cumple |
| azul sobre hoja | #8FB0F4 / #151B25 | 7,97 : 1 | cumple |
| grafito sobre mesa | #A3B0C2 / #0E131B | 8,47 : 1 | cumple |
| grafito sobre hoja | #A3B0C2 / #151B25 | 7,85 : 1 | cumple |
| suave sobre mesa | #7D8BA0 / #0E131B | 5,39 : 1 | cumple |
| suave sobre hoja | #7D8BA0 / #151B25 | 5,00 : 1 | cumple |
| mesa sobre azul | #0E131B / #8FB0F4 | 8,59 : 1 | cumple |
| mesa sobre lapiz | #0E131B / #F0C060 | 11,01 : 1 | cumple |

## La app, claro (el rótulo y el lavado)

| Par | Colores | Contraste | |
| --- | --- | --- | --- |
| rotulo sobre mesa | #4A5A72 / #E9EDF1 | 5,96 : 1 | cumple |
| rotulo sobre hoja | #4A5A72 / #FFFFFF | 7,01 : 1 | cumple |
| rotulo sobre lavado | #4A5A72 / #F3F6FB | 6,47 : 1 | cumple |
| grafito sobre lavado | #5B6B82 / #F3F6FB | 5,01 : 1 | cumple |
| tinta sobre lavado | #1F2A3D / #F3F6FB | 13,31 : 1 | cumple |
